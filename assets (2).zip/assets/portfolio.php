<!doctype html>
<html class="no-js" lang="en">



<head>

<?php include 'style.php'; ?>

    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Portfolio </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>



<body>

    

<?php include 'header.php'; ?>


    
        <!--breadcrumbs area start-->
        <div class="breadcrumbs_area" >
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb_content">
                            <h3>Our Work</h3>
                            <ul>
                                <li><a href="index.php">home</a></li>
                                <li>Our Work</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--breadcrumbs area end-->

        <section>
            <h2 class="text-center">Our Work</h2>
            <div class="container text-center d-flex justify-content-between">
                <button type="button" class="btn btn-secondary">Interior Plants</button>
                <button type="button" class="btn btn-secondary">Exterior Plants</button>
                <button type="button" class="btn btn-secondary">Living Walls</button>
                <button type="button" class="btn btn-secondary">Moss Designs</button>
                <button type="button" class="btn btn-secondary">Holiday Events</button>
                <button type="button" class="btn btn-secondary">Home Decore</button>
                
            </div>
        </section>



    
    <?php include 'script.php'; ?>
    <?php include 'footer.php'; ?>

</body>



</html>