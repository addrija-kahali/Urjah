<!doctype html>
<html class="no-js" lang="en">



<head>

<?php include 'style.php'; ?>

    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Welcome to URJAH </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>



<body>

    

<?php include 'header.php'; ?>


    
        <!--breadcrumbs area start-->
        <div class="breadcrumbs_area" >
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb_content">
                            <h3>Services</h3>
                            <ul>
                                <li><a href="index.php">home</a></li>
                                <li>Services</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-image">
                <img src="img/banner/bact.png" alt="img/banner/bact.png">
            </div>
        </div>
        <!--breadcrumbs area end-->



    <section class="services apt-50 apb-50 light-bg">

        
            <div class="container">
            <div class="row">
            <div class="col-lg-9 col-md-12">
                <h1 class="text-center">Interior Plants</h1>
                <hr>
                <div class="row">

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/I1.jpg" alt="">
                            </div>
                            
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/I2.jpg" alt="">
                            </div>
                            
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/I3.jpg" alt="">
                            </div>
                            
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/I4.jpg" alt="">
                            </div>
                            
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/I5.jpg" alt="">
                            </div>
                            
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/I6.jpg" alt="">
                            </div>
                            
                        </div>
                    </div>
                    
                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/I7.jpg" alt="">
                            </div>
                            
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/I8.jpg" alt="">
                            </div>
                            
                        </div>
                    </div>

                </div>

                <h1 class="text-center">Exterior Plants</h1>
                <hr>
                <div class="row">

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/E1.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/E2.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/E3.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/E4.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/E5.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/E6.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/E7.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/E8.jpg" alt="">
                            </div>
                        </div>
                    </div>

                </div>

                <h1 class="text-center">Holiday Decor</h1>
                <hr>
                <div class="row">

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/H1.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/H2.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/H3.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/H4.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    

                </div>

                <h1 class="text-center">Living Walls</h1>
                <hr>
                <div class="row">

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/L1.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/L2.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/L3.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/L4.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/L5.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/L6.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/L7.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/L8.jpg" alt="">
                            </div>
                        </div>
                    </div>

                </div>

                <h1 class="text-center">Moss Design</h1>
                <hr>
                <div class="row">

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/M1.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/M2.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/M3.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/M4.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/M5.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/M6.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/M7.jpg" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="single_services">
                            <div class="services_thumb">
                                <img src="assets/img/services/M8.jpg" alt="">
                            </div>
                        </div>
                    </div>

                </div>


                
            </div>
                <div class="col-lg-3 col-md-12">
                        <?php include 'form.php'; ?>
                    </div>
            </div>
            </div>
    </div>
    <!--services img end-->



    <!--services section area-->
    <div class="unlimited_services">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-12">
                    <div class="services_section_thumb">
                        <img src="assets/img/services/services4.jpg" alt="">
                    </div>
                </div>
                <div class="col-lg-6 col-md-12">
                    <div class="unlimited_services_content">
                        <h1>Our Vision</h1>
                        <p>At Urjha, our vision is to cultivate a greener world where nature harmoniously coexists with modern living. We strive to inspire and empower individuals to bring the beauty and tranquility of exotic plants into their homes, offices, and communities. By offering a diverse range of exquisite plants and innovative living wall solutions, we aim to transform spaces into lush, vibrant sanctuaries that promote well-being and environmental stewardship.
                            <br><br>
                            We believe in the transformative power of greenery to enhance the quality of life, foster creativity, and create serene, refreshing environments. Our commitment extends beyond just selling plants; we are dedicated to educating and guiding our customers on sustainable practices and the nurturing of their green spaces.
                            <br><br>
                            At Urjha, we envision a future where every living and working space is a testament to the beauty of nature, inspiring a deeper connection to the natural world and a collective responsibility to protect and cherish our environment for generations to come.
                        </p>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--services section end-->

    
    
    </section>

       
                        
    
    <?php include 'script.php'; ?>
    <?php include 'footer.php'; ?>

</body>



</html>