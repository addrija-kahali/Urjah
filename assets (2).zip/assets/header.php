


<div class="off_canvars_overlay">

    </div>
    <div class="offcanvas_menu">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="canvas_open">
                        <a href="javascript:void(0)"><i class="icon-menu"></i></a>
                    </div>
                    <div class="offcanvas_menu_wrapper">
                        <div class="canvas_close">
                            <a href="javascript:void(0)"><i class="icon-x"></i></a>
                        </div>
                        <div class="welcome-text">
                            <p>Free Delivery: Take advantage of our time to save event</p>
                        </div>
                        
                        
                        <div class="call-support">
                            <p>Call Support:<a href="#">+91 6297296544</a></p>
                        </div>
                        <div id="menu" class="text-left ">
                            <ul class="offcanvas_main_menu">
                                <li class="menu-item-has-children active">
                                    <a href="#">Home</a>
                                    <ul class="sub-menu">
                                        <li><a href="index.html">Home 1</a></li>
                                        <li><a href="index-2.html">Home 2</a></li>
                                        <li><a href="index-3.html">Home 3</a></li>
                                        <li><a href="index-4.html">Home 4</a></li>
                                        <li><a href="index-5.html">Home 5</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="#">Shop</a>
                                    <ul class="sub-menu">
                                        <li class="menu-item-has-children">
                                            <a href="#">Shop Layouts</a>
                                            <ul class="sub-menu">
                                                <li><a href="shop.html">shop</a></li>
                                                <li><a href="shop-fullwidth.html">Full Width</a></li>
                                                <li><a href="shop-fullwidth-list.html">Full Width list</a></li>
                                                <li><a href="shop-right-sidebar.html">Right Sidebar </a></li>
                                                <li><a href="shop-right-sidebar-list.html"> Right Sidebar list</a></li>
                                                <li><a href="shop-list.html">List View</a></li>
                                            </ul>
                                        </li>
                                        <li class="menu-item-has-children">
                                            <a href="#">other Pages</a>
                                            <ul class="sub-menu">
                                                <li><a href="cart.html">cart</a></li>
                                                <li><a href="wishlist.html">Wishlist</a></li>
                                                <li><a href="checkout.html">Checkout</a></li>
                                                <li><a href="my-account.html">my account</a></li>
                                                <li><a href="404.html">Error 404</a></li>
                                            </ul>
                                        </li>
                                        <li class="menu-item-has-children">
                                            <a href="#">Product Types</a>
                                            <ul class="sub-menu">
                                                <li><a href="product-details.html">product details</a></li>
                                                <li><a href="product-sidebar.html">product sidebar</a></li>
                                                <li><a href="product-grouped.html">product grouped</a></li>
                                                <li><a href="variable-product.html">product variable</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="#">blog</a>
                                    <ul class="sub-menu">
                                        <li><a href="blog.html">blog</a></li>
                                        <li><a href="blog-details.html">blog details</a></li>
                                        <li><a href="blog-fullwidth.html">blog fullwidth</a></li>
                                        <li><a href="blog-sidebar.html">blog sidebar</a></li>
                                    </ul>

                                </li>
                                <li class="menu-item-has-children">
                                    <a href="#">pages </a>
                                    <ul class="sub-menu">
                                        <li><a href="about.html">About Us</a></li>
                                        <li><a href="services.html">services</a></li>
                                        <li><a href="faq.html">Frequently Questions</a></li>
                                        <li><a href="contact.html">contact</a></li>
                                        <li><a href="login.html">login</a></li>
                                        <li><a href="404.html">Error 404</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="my-account.html">my account</a>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="about.html">about Us</a>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="contact.html"> Contact Us</a>
                                </li>
                            </ul>
                        </div>

                        <div class="offcanvas_footer">
                            <span><a href="#"><i class="fa fa-envelope-o"></i> demo@example.com</a></span>
                            <ul>
                                <li class="facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li class="twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li class="pinterest"><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                                <li class="google-plus"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                <li class="linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php include 'style.php'; ?>
<?php include 'script.php'; ?>
<header>
        <div class="main_header header_3 header_transparent sticky-header">
            <div class="header_container">
                <div class="container-fluid">
                    <div class="row align-items-center">
                        <div class="col-lg-2 col-md-3 col-4">
                            <div class="logo">
                                <a href="index.php"><img src="assets/img/logo/urjah.png" alt="urjah"></a>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <!--main menu start-->
                            <div class="main_menu menu_three menu_position">
                                <nav>
                                    <ul>
                                        
                                        <li class="mega_items"><a href="#">Plants<i
                                                    class="fa fa-angle-down"></i></a>
                                            <div class="mega_menu">
                                                <ul class="mega_menu_inner">
                                                <li><a href="#">Shop By name</a>
                                                            <ul>
                                                                <li><a href="">Adenium Obesum</a></li>
                                                                <li><a href="">Fern</a></li>
                                                                <li><a href="">Succulents</a></li>
                                                                <li><a href="">Cactus</a></li>
                                                                <li><a href="">Blooming</a></li>
                                                                <li><a href="">Roses</a></li>
                                                                <li><a href="">Ever Green</a></li>
                                                                <li><a href="">Vines & Creeper</a></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#">Exotic Plants</a>
                                                            <ul>
                                                                <li><a href="">Bonsai</a></li>
                                                                <li><a href="">Orchids</a></li>
                                                                <li><a href="">Adennium Arabicum</a></li>
                                                                <li><a href="">Kokedamd</a></li>
                                                                <li><a href="">Fruit & Trees</a></li>
                                                                <li><a href="">Herbs</a></li>
                                                                <li><a href="">Air plant</a></li>
                                                                <li><a href="">Bromeliadn</a></li>
                                                                
                                                            </ul>
                                                        </li>
                                                        <li><a href="#">Shop By Use</a>
                                                            <ul>
                                                                <li><a href="">Air Purifier</a></li>
                                                                <li><a href="">Low Maintaince</a></li>
                                                                <li><a href="">Indoor & Outdoor</a></li>
                                                                <li><a href="">Vastu/Goodluck</a></li>
                                                                <li><a href="">Medicinal</a></li>
                                                                <li><a href="">Balcony</a></li>
                                                                <li><a href="">Living Room</a></li>
                                                                <li><a href="">Window Ledge & Office</a></li>                                                         
                                                            </ul>
                                                        </li>
                                                </ul>
                                            </div>
                                        </li>


                                        <li><a href="#">Pots<i class="fa fa-angle-down"></i></a>
                                            <ul class="sub_menu pages">
                                                <li><a href="">Resin Pots</a></li>
                                                <li><a href="">Ceramic Pots</a></li>
                                                <li><a href="">Wooden Pots</a></li>
                                                <li><a href="">Terracotta Pots</a></li>
                                                <li><a href="">Metal Pots</a></li>
                                                <li><a href="">Vases</a></li>
                                                <li><a href="">Glass Pots</a></li>
                                            </ul>
                                        </li>

                                        <li><a href="#">Gifting<i class="fa fa-angle-down"></i></a>
                                            <ul class="sub_menu pages">
                                               
                                                <li><a href="">Corporate/Bulk Guifting</a></li>
                                                <li><a href="">Personalised Giftings</a></li>
                                                <li><a href="">Giftcard</a></li>
                                            </ul>
                                            
                                        </li>
                                        
                                        <li><a href="#">Home Decore<i class="fa fa-angle-down"></i></a>
                                            <ul class="sub_menu pages">
                                            <li><a href="">Preserved Nature Tabletops</a></li>
                                            <li><a href="">Moss Frames</a></li>
                                            <li><a href="">Miniatures</a></li>
                                            <li><a href="">Terrarium Kits</a></li>
                                            <li><a href="">Garden Art</a></li>
                                            <li><a href="">Pebbles & Stones</a></li>
                                            <li><a href="">Dream Catchers</a></li>
                                            <li><a href="">Zen Garden</a></li>
                                            
                                            </ul>
                                            
                                        </li>

                                        <li><a href="#">Ornament<i class="fa fa-angle-down"></i></a>
                                            <ul class="sub_menu pages">
                                               
                                                <li><a href="">Wearable Nature</a></li>
                                                <li><a href="">Stationery</a></li>
                                            </ul>
                                            
                                        </li>

                                        <li><a href="services.php">Services</a></li>

                                        <li><a href="contact.php"> Contact Us</a></li>
                                        
                                    </ul>
                                </nav>
                            </div>
                            <!--main menu end-->
                        </div>

                        <div class="col-lg-4 col-md-6 col-sm-5 col-6">
                            <div class="header_right_info header_right_two">
                                <div class="search_container">
                                    <form action="#">
                                        <div class="search_box">
                                            <input placeholder="Search product..." type="text">
                                            <button type="submit"><i class="icon-search"></i></button>
                                        </div>
                                    </form>
                                </div>
                                <div class="header_account_area">
                                    <div class="header_account-list top_links">
                                        <a href="#"><i class="icon-users"></i></a>
                                        <ul class="dropdown_links">
                                            <li><a href="checkout.html">Checkout </a></li>
                                            <li><a href="my-account.html">My Account </a></li>
                                            <li><a href="cart.html">Shopping Cart</a></li>
                                            <li><a href="wishlist.html">Wishlist</a></li>
                                        </ul>
                                    </div>
                                    <div class="header_account-list header_wishlist">
                                        <a href="wishlist.html"><i class="icon-heart"></i></a>
                                    </div>
                                    <div class="header_account-list  mini_cart_wrapper">
                                        <a href="javascript:void(0)"><i class="icon-shopping-bag"></i><span
                                                class="item_count">2</span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--mini cart-->
        <div class="mini_cart">
            <div class="cart_gallery">
                <div class="cart_close">
                    <div class="cart_text">
                        <h3>cart</h3>
                    </div>
                    <div class="mini_cart_close">
                        <a href="javascript:void(0)"><i class="icon-x"></i></a>
                    </div>
                </div>
                <div class="cart_item">
                    <div class="cart_img">
                        <a href="#"><img src="assets/img/s-product/product.jpg" alt=""></a>
                    </div>
                    <div class="cart_info">
                        <a href="#">Primis In Faucibus</a>
                        <p>1 x <span> $65.00 </span></p>
                    </div>
                    <div class="cart_remove">
                        <a href="#"><i class="icon-x"></i></a>
                    </div>
                </div>
                <div class="cart_item">
                    <div class="cart_img">
                        <a href="#"><img src="assets/img/s-product/product2.jpg" alt=""></a>
                    </div>
                    <div class="cart_info">
                        <a href="#">Letraset Sheets</a>
                        <p>1 x <span> $60.00 </span></p>
                    </div>
                    <div class="cart_remove">
                        <a href="#"><i class="icon-x"></i></a>
                    </div>
                </div>
            </div>
            <div class="mini_cart_table">
                <div class="cart_table_border">
                    <div class="cart_total">
                        <span>Sub total:</span>
                        <span class="price">$125.00</span>
                    </div>
                    <div class="cart_total mt-10">
                        <span>total:</span>
                        <span class="price">$125.00</span>
                    </div>
                </div>
            </div>
            <div class="mini_cart_footer">
                <div class="cart_button">
                    <a href="cart.html"><i class="fa fa-shopping-cart"></i> View cart</a>
                </div>
                <div class="cart_button">
                    <a class="active" href="checkout.html"><i class="fa fa-sign-in"></i> Checkout</a>
                </div>

            </div>
        </div>
        <!--mini cart end-->
    </header>
    <!--header area end-->