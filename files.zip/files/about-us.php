<!doctype html>
<html class="no-js" lang="en">



<head>

<?php include 'style.php'; ?>

    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Welcome to URJAH </title>
    <meta name="description" content="">
    

</head>



<body>

    

<?php include 'header.php'; ?>


    <section>
        <!--breadcrumbs area start-->
        <div class="breadcrumbs_area" style="">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb_content">
                            <h3>About Us</h3>
                            <ul>
                                <li><a href="index.html">home</a></li>
                                <li>About Us</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--breadcrumbs area end-->
    </section>



    <div class="unlimited_services">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-12">
                    <div class="services_section_thumb">
                        <img src="assets/img/abou.jpg" alt="">
                    </div>
                </div>
                <div class="col-lg-6 col-md-12">
                    <div class="unlimited_services_content">
                    <h1>Discover the World's Most Exotic and Rare Plants at Urjah</h1>
                            <p>Welcome to Urjah, your premier destination for discovering exotic and rare plants from around the globe. At Urjah, we pride ourselves on curating a diverse collection of unique flora, meticulously sourced from the most remote and verdant corners of the world. Whether you're an avid botanist, a passionate gardener, or simply a lover of extraordinary plants, our selection offers something special for everyone. Explore our site to find detailed information, vibrant images, and expert care tips for each plant, ensuring your botanical treasures thrive in their new home. Join our community at Urjah and embark on a journey through nature's most exquisite and rare botanical wonders.</p>
                            <div class="about_signature">
                                <!--<img src="assets/img/about/about-us-signature.png" alt="">-->
                            </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!--about section end-->

    
    
    
    <?php include 'script.php'; ?>
    <?php include 'footer.php'; ?>

</body>



</html>