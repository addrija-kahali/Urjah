
                        
                        <div class="contact_message form">
                            <h3>Send Enquary</h3>
                            <form id="contact-form" method="POST" action="https://htmldemo.net/lukani/lukani/assets/mail.php">
                                <p>
                                    <label> Your Name (required)</label>
                                    <input name="name" placeholder="Name *" type="text">
                                </p>
                                <p>
                                    <label> Your Email (required)</label>
                                    <input name="email" placeholder="Email *" type="email">
                                </p>
                                <p>
                                    <label> Your Phone Number (required)</label>
                                    <input name="number" placeholder="Phone Number *" type="Phone">
                                </p>
                                <p>
                                    <label> Subject</label>
                                    <input name="subject" placeholder="Subject *" type="text">
                                </p>
                                <div class="contact_textarea">
                                    <label> Your Message</label>
                                    <textarea placeholder="Message *" name="message" class="form-control2"></textarea>
                                </div>
                                <button type="submit"> Send</button>
                                <p class="form-messege"></p>
                            </form>

                        </div>
                    